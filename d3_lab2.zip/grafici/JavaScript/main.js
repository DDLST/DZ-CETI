function getDataForm() {
   return {
      ox: document.querySelector('input[name="ox"]:checked').value,
      max: document.getElementById("maxHeight").checked,
      min: document.getElementById("minHeight").checked,
      typeGraph: document.getElementById("typeGraph").value
   };
}

function checkOY() {
   const oyBlock = document.getElementById("oyBlock");
   const dataForm = getDataForm();

   if (!dataForm.max && !dataForm.min) {
      oyBlock.classList.add("error");
      d3.select("svg").selectAll("*").remove();
      return null;
   }

   oyBlock.classList.remove("error");
   return dataForm;
}

document.addEventListener("DOMContentLoaded", function() {
   showTable("build", floods);
   drawGraph(floods, getDataForm());

   const btn = document.getElementById("toggleBtn");
   const table = d3.select("#build");
   const buildBtn = document.getElementById("buildGraph");

   btn.addEventListener("click", function() {
      if (btn.textContent === "Показать таблицу") {
         showTable("build", floods);
         btn.textContent = "Скрыть таблицу";
      } else {
         table.selectAll("tr").remove();
         btn.textContent = "Показать таблицу";
      }
   });

   buildBtn.addEventListener("click", function() {
      const dataForm = checkOY();

      if (dataForm) {
         drawGraph(floods, dataForm);
      }
   });
});
