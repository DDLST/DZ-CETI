// Входные данные:
//   data - исходный массив (например, floods)
//   key - поле, по которому осуществляется группировка

function createArrGraph(data, key) {
    const groupObj = d3.group(data, d => d[key]);

    let arrGraph = [];
    for (let entry of groupObj) {
        const minMax = d3.extent(entry[1].map(d => d["Высота, см"]));
        arrGraph.push({ labelX: entry[0], values: minMax });
    }

    return arrGraph;
}

/* добавить новый параметр - данные формы */
function drawGraph(data, dataForm) {
    // значения по оси OX
    const keyX = dataForm.ox;

    // создаем массив для построения графика
    let arrGraph = createArrGraph(data, keyX);

    /* если выбран Год, то отсортировать массив по labelX */
    if (keyX == "Год") {
        arrGraph.sort((a, b) => a.labelX - b.labelX);
    }

    const svg = d3.select("svg");
    svg.selectAll("*").remove();

    // создаем словарь с атрибутами области вывода графика
    const attr_area = {
        width: parseFloat(svg.style("width")),
        height: parseFloat(svg.style("height")),
        marginX: 50,
        marginY: 50
    };

    // создаем шкалы преобразования и выводим оси
    const [scX, scY] = createAxis(svg, arrGraph, attr_area, dataForm);

    // рисуем график / графики
    if (dataForm.typeGraph == "Точечная диаграмма") {
        if (dataForm.max) {
            createChart(svg, arrGraph, scX, scY, attr_area, "red", 1);
        }

        if (dataForm.min) {
            createChart(svg, arrGraph, scX, scY, attr_area, "blue", 0);
        }
    }
    else if (dataForm.typeGraph == "График") {
        if (dataForm.max) {
            createLineChart(svg, arrGraph, scX, scY, attr_area, "red", 1);
        }

        if (dataForm.min) {
            createLineChart(svg, arrGraph, scX, scY, attr_area, "blue", 0);
        }
    }
    else {
        if (dataForm.max) {
            createHistogram(svg, arrGraph, scX, scY, attr_area, "red", 1, dataForm);
        }

        if (dataForm.min) {
            createHistogram(svg, arrGraph, scX, scY, attr_area, "blue", 0, dataForm);
        }
    }
}

function createAxis(svg, data, attr_area, dataForm) {
    // находим интервал значений, которые нужно отложить по оси OY
    let arrY = [];

    if (dataForm.max) {
        arrY = arrY.concat(data.map(d => d.values[1]));
    }

    if (dataForm.min) {
        arrY = arrY.concat(data.map(d => d.values[0]));
    }

    const [min, max] = d3.extent(arrY);

    // функция интерполяции значений на оси
    // по оси OX текстовые значения
    const scaleX = d3.scaleBand()
                    .domain(data.map(d => d.labelX))
                    .range([0, attr_area.width - 2 * attr_area.marginX]);

    const scaleY = d3.scaleLinear()
                    .domain([min * 0.85, max * 1.1])
                    .range([attr_area.height - 2 * attr_area.marginY, 0]);

    // создание осей
    const axisX = d3.axisBottom(scaleX);
    const axisY = d3.axisLeft(scaleY);

    // отрисовка осей в SVG-элементе
    svg.append("g")
        .attr("transform", `translate(${attr_area.marginX}, ${attr_area.height - attr_area.marginY})`)
        .call(axisX)
        .selectAll("text")
        .style("text-anchor", "end")
        .attr("dx", "-.8em")
        .attr("dy", ".15em")
        .attr("transform", () => "rotate(-45)");

    svg.append("g")
        .attr("transform", `translate(${attr_area.marginX}, ${attr_area.marginY})`)
        .call(axisY);

    return [scaleX, scaleY];
}

function createChart(svg, data, scaleX, scaleY, attr_area, color, ind) {
    const r = 4;

    svg.selectAll(".dot" + color + ind)
        .data(data)
        .enter()
        .append("circle")
        .attr("r", r)
        .attr("cx", d => scaleX(d.labelX) + scaleX.bandwidth() / 2)
        .attr("cy", d => scaleY(d.values[ind]))
        .attr("transform", `translate(${attr_area.marginX}, ${attr_area.marginY})`)
        .style("fill", color);
}

function createLineChart(svg, data, scaleX, scaleY, attr_area, color, ind) {
    const line = d3.line()
        .x(d => scaleX(d.labelX) + scaleX.bandwidth() / 2)
        .y(d => scaleY(d.values[ind]));

    svg.append("path")
        .datum(data)
        .attr("d", line)
        .attr("transform", `translate(${attr_area.marginX}, ${attr_area.marginY})`)
        .style("fill", "none")
        .style("stroke", color)
        .style("stroke-width", "1.5px");

    svg.selectAll(".lineDot" + color + ind)
        .data(data)
        .enter()
        .append("circle")
        .attr("r", 3)
        .attr("cx", d => scaleX(d.labelX) + scaleX.bandwidth() / 2)
        .attr("cy", d => scaleY(d.values[ind]))
        .attr("transform", `translate(${attr_area.marginX}, ${attr_area.marginY})`)
        .style("fill", color);
}

/* функция для построения гистограммы */
function createHistogram(svg, data, scaleX, scaleY, attr_area, color, ind, dataForm) {
    let width = scaleX.bandwidth() - 2;
    let shift = 1;

    if (dataForm.max && dataForm.min) {
        width = scaleX.bandwidth() / 2 - 2;

        if (ind == 0) {
            shift = scaleX.bandwidth() / 2 + 1;
        }
    }

    svg.selectAll(".bar" + color + ind)
        .data(data)
        .enter()
        .append("rect")
        .attr("x", d => scaleX(d.labelX) + shift)
        .attr("y", d => scaleY(d.values[ind]))
        .attr("width", width)
        .attr("height", d => attr_area.height - 2 * attr_area.marginY - scaleY(d.values[ind]))
        .attr("transform", `translate(${attr_area.marginX}, ${attr_area.marginY})`)
        .style("fill", color);
}
