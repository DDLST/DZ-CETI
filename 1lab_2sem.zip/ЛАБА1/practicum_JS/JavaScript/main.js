let currTable = [...buildings];
document.addEventListener("DOMContentLoaded", function () {
  const sort = document.getElementById("sort");
  const filtr = document.getElementById("filter");
  const filtrBtn = filtr.querySelectorAll('input[type="button"]');
  const sortBtn = sort.querySelectorAll('input[type="button"]');
  const firstSelect = sort.querySelector("select");

  createTable(buildings, "list");
  setSortSelects(buildings[0], sort);

  filtrBtn[0].onclick = function () {
    clearSort(sort, "list", buildings);
    currTable = filterTable(buildings, "list", filtr);
  };

  filtrBtn[1].onclick = function () {
    clearSort(sort, "list", buildings);
    clearFilter(buildings, "list", filtr);
    currTable = [...buildings];
  };

  firstSelect.onchange = function () {
    changeNextSelect(this, "fieldsSecond");
  };

  sortBtn[0].onclick = function () {
    sortTable("list", sort);
  };

  sortBtn[1].onclick = function () {
    clearSort(sort, "list", currTable);
  };
});

// формирование полей элемента списка с заданным текстом и значением

const createOption = (str, val) => {
  let item = document.createElement("option");
  item.text = str;
  item.value = val;
  return item;
};

// формирование поля со списком
// параметры – массив со значениями элементов списка и элемент select

const setSortSelect = (arr, sortSelect) => {
  // создаем OPTION Нет и добавляем ее в SELECT
  sortSelect.append(createOption("Нет", 0));
  // перебираем массив со значениями опций
  arr.forEach((item, index) => {
    // создаем OPTION из очередного ключа и добавляем в SELECT
    // значение атрибута VALUE увеличиваем на 1, так как значение 0 имеет опция Нет
    sortSelect.append(createOption(item, index + 1));
  });
};

// формируем поля со списком для многоуровневой сортировки
const setSortSelects = (data, dataForm) => {
  // выделяем ключи словаря в массив
  const head = Object.keys(data);

  // находим все SELECT в форме
  const allSelect = dataForm.getElementsByTagName("select");

  for (const item of allSelect) {
    // формируем очередной SELECT
    setSortSelect(head, item);

    if (item !== allSelect[0]) {
      item.disabled = true;
    }
  }
};

// настраиваем поле для следующего уровня сортировки
const changeNextSelect = (curSelect, nextSelectId) => {
  let nextSelect = document.getElementById(nextSelectId);

  nextSelect.disabled = false;

  // в следующем SELECT выводим те же option, что и в текущем
  nextSelect.innerHTML = curSelect.innerHTML;

  // удаляем в следующем SELECT уже выбранную в текущем опцию
  // если это не первая опция - отсутствие сортировки
  if (curSelect.value != 0) {
    nextSelect.remove(curSelect.value);
  } else {
    nextSelect.disabled = true;
  }
};
