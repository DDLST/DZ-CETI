/*формируем массив для сортировки по двум уровням вида 
  [
    {column: номер столбца, по которому осуществляется сортировка, 
     direction: порядок сортировки (true по убыванию, false по возрастанию)
    }, 
    ...
   ]
*/
const createSortArr = (data) => {
  let sortArr = [];

  const sortSelects = data.getElementsByTagName("select");

  for (const item of sortSelects) {
  
    const keySort = item.value;

    if (keySort == 0) {
      break;
    }
    
    const desc = document.getElementById(item.id + "Desc").checked;

    sortArr.push({ column: keySort - 1, direction: desc });
  }
  return sortArr;
};

const sortTable = (idTable, formData) => {
  // формируем управляющий массив для сортировки
  const sortArr = createSortArr(formData);


  if (sortArr.length === 0) {
    clearTable(idTable);
    createTable(currTable, idTable);
    return false;
  }

  //находим нужную таблицу
  let table = document.getElementById(idTable);

  // преобразуем строки таблицы в массив
  let rowData = Array.from(table.rows);

  // удаляем элемент с заголовками таблицы
  const headerRow = rowData.shift();

  //сортируем данные по всем уровням сортировки
  rowData.sort((first, second) => {
    for (let { column, direction } of sortArr) {
      const firstCell = first.cells[column].innerHTML;
      const secondCell = second.cells[column].innerHTML;

      // Проверяем, являются ли значения числами
      const firstNum = parseFloat(firstCell);
      const secondNum = parseFloat(secondCell);

      // используем localeCompare для корректного сравнения
      let comparison;

      // Если оба значения - числа, сортируем как числа
      if (!isNaN(firstNum) && !isNaN(secondNum)) {
        comparison = firstNum - secondNum;
      } else {
        comparison = firstCell.localeCompare(secondCell);
      }

      // учитываем направление сортировки
      if (comparison !== 0) {
        return direction ? -comparison : comparison;
      }
    }
    return 0;
  });

  //выводим отсортированную таблицу на страницу
  table.append(headerRow);

  let tbody = document.createElement("tbody");
  rowData.forEach((item) => {
    tbody.append(item);
  });
  table.append(tbody);
};

const clearSort = (dataForm, idTable, data) => {
  clearTable(idTable);
  createTable(data, idTable);
  resetSort(dataForm);
};

const resetSort = (dataForm) => {
  const selects = dataForm.getElementsByTagName("select");

  const descCheckboxes = dataForm.querySelectorAll('input[type="checkbox"]');
  selects[0].value = "0";

  for (let i = 1; i < selects.length; i++) {
    selects[i].value = "0";
    selects[i].disabled = true;
  }

  descCheckboxes.forEach((checkbox) => {
    checkbox.checked = false;
  });
};
