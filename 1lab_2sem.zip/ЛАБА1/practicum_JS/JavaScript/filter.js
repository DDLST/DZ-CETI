// устанавливаем соответствие между полями формы и столбцами таблицы
const correspond = {
  Название: "structure",
  Тип: "category",
  Страна: "country",
  Город: "city",
  Год: ["yearFrom", "yearTo"],
  Высота: ["heightFrom", "heightTo"],
};

/* Структура возвращаемого ассоциативного массива:
{
    input_id: input_value,
    ...
}
*/
const dataFilter = (dataForm) => {
  let dictFilter = {};
  // перебираем все элементы формы с фильтрами
  for (const item of dataForm.elements) {
    // получаем значение элемента
    let valInput = item.value;
    // если поле типа text - приводим его значение к нижнему регистру
    if (item.type === "text") {
      valInput = valInput.toLowerCase();
    }
    if (valInput === "" && item.id.includes("From")) {
      valInput = -Infinity;
    }
    if (valInput === "" && item.id.includes("To")) {
      valInput = +Infinity;
    }
    if (item.type === "number") {
      valInput = Number(valInput);
    }

    // формируем очередной элемент ассоциативного массива
    if (item.id !== "") {
      dictFilter[item.id] = valInput;
    }
  }
  return dictFilter;
};

// фильтрация таблицы
const filterTable = (data, idTable, dataForm) => {
  // получаем данные из полей формы
  const datafilter = dataFilter(dataForm);

  // выбираем данные соответствующие фильтру и формируем таблицу из них
  let tableFilter = data.filter((item) => {
    /* в этой переменной будут "накапливаться" результаты сравнения данных
           с параметрами фильтра */
    let result = true;

    // строка соответствует фильтру, если сравнение всех значения из input
    // со значением ячейки очередной строки - истина
    Object.entries(item).map(([key, val]) => {
      // текстовые поля проверяем на вхождение
      if (typeof val == "string") {
        result &&= val.toLowerCase().includes(datafilter[correspond[key]]);
      }

      if (typeof val == "number") {
        result &&=
          datafilter[correspond[key][0]] <= val &&
          val <= datafilter[correspond[key][1]];
      }
    });

    return result;
  });

  // очистить данные таблицы
  clearTable(idTable);

  // показать на странице таблицу с отфильтрованными строками
  if (tableFilter.length > 0) {
    createTable(tableFilter, idTable);
  } else {
    const header = createHeaderRow(Object.keys(data[0]));
    document.getElementById(idTable).append(header);
  }

  return tableFilter;
};

// очистка формы
const clearFilter = (data, idTable, dataForm) => {
  const elements = dataForm.elements;

  for (const item of elements) {
    // Очищаем поля ввода
    if (item.type === "text" || item.type === "number") {
      item.value = "";
    }
  }

  clearTable(idTable);
  createTable(data, idTable);
};
