let currTable = [...floods];
document.addEventListener("DOMContentLoaded", function () {
  const sort = document.getElementById("sort");
  const filtr = document.getElementById("filter");
  const filtrBtn = filtr.querySelectorAll('input[type="button"]');
  const sortBtn = sort.querySelectorAll('input[type="button"]');
  const selects = sort.querySelectorAll("select");

  createTable(floods, "list");
  setSortSelects(floods[0], sort);

  filtrBtn[0].onclick = function () {
    clearSort(sort, "list", floods);
    currTable = filterTable(floods, "list", filtr);
  };

  filtrBtn[1].onclick = function () {
    clearSort(sort, "list", floods);
    clearFilter(floods, "list", filtr);
    currTable = [...floods];
  };

  selects[0].onchange = function () {
    changeNextSelect(this, "fieldsSecond");
  };

  selects[1].onchange = function () {
    changeNextSelect(this, "fieldsThird");
  };

  sortBtn[0].onclick = function () {
    sortTable("list", sort);
  };

  sortBtn[1].onclick = function () {
    clearSort(sort, "list", currTable);
  };
});

// формирование полей элемента списка с заданным текстом и значением

const createOption = (str, val) => {
  let item = document.createElement("option");
  item.text = str;
  item.value = val;
  return item;
};

// формирование поля со списком
// параметры – массив со значениями элементов списка и элемент select

const setSortSelect = (arr, sortSelect) => {
  // создаем OPTION Нет и добавляем ее в SELECT
  sortSelect.append(createOption("Нет", 0));
  // перебираем массив со значениями опций
  arr.forEach((item, index) => {
    // создаем OPTION из очередного ключа и добавляем в SELECT
    // значение атрибута VALUE увеличиваем на 1, так как значение 0 имеет опция Нет
    sortSelect.append(createOption(item, index + 1));
  });
};

// формируем поля со списком для многоуровневой сортировки
const setSortSelects = (data, dataForm) => {
  // выделяем ключи словаря в массив
  const head = Object.keys(data);

  // находим все SELECT в форме
  const allSelect = dataForm.getElementsByTagName("select");

  for (const item of allSelect) {
    // формируем очередной SELECT
    setSortSelect(head, item);

    if (item !== allSelect[0]) {
      item.disabled = true;
    }
  }
};

// настраиваем поле для следующего уровня сортировки
const changeNextSelect = (curSelect, nextSelectId) => {
  const sortForm = document.getElementById("sort");
  const allSelects = Array.from(sortForm.getElementsByTagName("select"));
  const currentIndex = allSelects.indexOf(curSelect);

  // проверяем, есть ли следующий уровень
  if (!nextSelectId || currentIndex >= allSelects.length - 1) return;

  const nextSelect = document.getElementById(nextSelectId);
  const prevValue = nextSelect.value;

  // копируем опции
  nextSelect.innerHTML = curSelect.innerHTML;
  nextSelect.disabled = curSelect.value == "0";

  if (curSelect.value != "0") {
    // удаляем выбранные опции
    const selectedValues = allSelects
      .slice(0, currentIndex + 1)
      .map((s) => s.value)
      .filter((v) => v != "0");

    selectedValues.forEach((value) => {
      Array.from(nextSelect.options).forEach((opt, idx) => {
        if (opt.value == value) nextSelect.remove(idx);
      });
    });

    // восстанавливаем значение (чтобы при изменении уровней не выставлялось нет)
    const hasPrevValue =
      prevValue &&
      prevValue != "0" &&
      Array.from(nextSelect.options).some((opt) => opt.value == prevValue);
    nextSelect.value = hasPrevValue ? prevValue : "0";
  }

  changeNextSelect(nextSelect, allSelects[currentIndex + 2]?.id);
};