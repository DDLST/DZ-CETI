const createTable = (data, idTable) => {
  const table = document.getElementById(idTable);
  const header = Object.keys(data[0]);

  /* создание шапки таблицы */
  const headerRow = createHeaderRow(header);
  table.append(headerRow);

  /* создание тела таблицы */
  const bodyRows = createBodyRows(data);
  table.append(bodyRows);
};

const createHeaderRow = (headers) => {
  const tr = document.createElement("tr");
  headers.forEach((header) => {
    const th = document.createElement("th");
    th.innerHTML = header;
    tr.append(th);
  });
  return tr;
};

const createBodyRows = (data) => {
  const tbody = !document.querySelector("tbody")
    ? document.createElement("tbody")
    : document.querySelector("tbody");
  data.forEach((elem) => {
    const tr = document.createElement("tr");
    Object.values(elem).forEach((item) => {
      const td = document.createElement("td");
      td.innerHTML = item;
      tr.append(td);
    });
    tbody.append(tr);
  });
  return tbody;
};

const clearTable = (idTable) => {
  const table = document.getElementById(idTable);
  while (table.rows.length > 0) {
    table.deleteRow(0);
  }
};