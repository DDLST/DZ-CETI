/*формируем массив для сортировки по двум уровням вида 
  [
    {column: номер столбца, по которому осуществляется сортировка, 
     direction: порядок сортировки (true по убыванию, false по возрастанию)
    }, 
    ...
   ]
*/
const createSortArr = (data) => {
  let sortArr = [];

  const sortSelects = data.getElementsByTagName("select");

  for (const item of sortSelects) {
    // получаем номер выбранной опции
    const keySort = item.value;
    // в случае, если выбрана опция Нет, заканчиваем формировать массив
    if (keySort == 0) {
      break;
    }
    // получаем порядок сортировки очередного уровня
    // имя флажка сформировано как имя поля SELECT и слова Desc
    const desc = document.getElementById(item.id + "Desc").checked;
    // очередной элемент массива - по какому столбцу и в каком порядке сортировать
    sortArr.push({ column: keySort - 1, direction: desc });
  }
  return sortArr;
};

const sortTable = (idTable, formData) => {
  const sortArr = createSortArr(formData);

  if (sortArr.length === 0) {
    if (currTable.length > 0) {
      clearTable(idTable);
      createTable(currTable, idTable);
    }
    return false;
  }

  
  let table = document.getElementById(idTable);
  

  let rowData = Array.from(table.rows);


  const headerRow = rowData.shift();
  const compareNumber = ["Год", "Высота, см", "Жертвы", "Ущерб, млрд руб."];


  rowData.sort((first, second) => {
    for (let { column, direction } of sortArr) {
      const firstCell = first.cells[column].innerHTML;
      const secondCell = second.cells[column].innerHTML;

      // Проверяем, являются ли значения числами
      const firstNum = parseFloat(firstCell);
      const secondNum = parseFloat(secondCell);

   
      let comparison;
      if (compareNumber.includes(headerRow.cells[column].textContent)) {
        comparison = firstNum - secondNum;
      } else {
        comparison = firstCell.localeCompare(secondCell);
      }

      if (comparison !== 0) {
        return direction ? -comparison : comparison;
      }
    }
    return 0;
  });


  table.append(headerRow);

  let tbody = document.createElement("tbody");
  rowData.forEach((item) => {
    tbody.append(item);
  });
  table.append(tbody);
};

const clearSort = (dataForm, idTable, data) => {
  clearTable(idTable);
  if (data.length > 0) {
    createTable(data, idTable);
  } else {
    const header = Object.keys(floods[0]);
    const headerRow = createHeaderRow(header);
    document.getElementById(idTable).append(headerRow);
  }
  resetSort(dataForm);
};

const resetSort = (dataForm) => {
  const selects = dataForm.getElementsByTagName("select");

  const descCheckboxes = dataForm.querySelectorAll('input[type="checkbox"]');
  selects[0].value = "0";

  for (let i = 1; i < selects.length; i++) {
    selects[i].value = "0";
    selects[i].disabled = true;
  }

  descCheckboxes.forEach((checkbox) => {
    checkbox.checked = false;
  });
};