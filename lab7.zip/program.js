/* 
   program.js — Вариант 15 (Калькулятор комплексных чисел)

   - Пользователь выбирает форму задания комплексного числа:
       1) Алгебраическая: z = a + bi  (ввод Re=a и Im=b)
       2) Тригонометрическая: z = r(cosφ + i sinφ)  (ввод r и φ)
   - Выбирает одну или несколько операций (select multiple)
   - Нажимает "Вычислить" → получаем результаты в блоке output
   - Нажимает "Очистить" → всё очищается
   - Нажимает "Показать" → меняются подписи полей и картинка
   ВАЖНО по требованиям:
   1) НЕТ onclick в HTML — все события навешиваются здесь (addEventListener)
   2) Доступ к элементам формы через form.elements (переменная el)
   3) Ошибки ввод/выбора операций — стилями (без alert), с причиной
*/


/* 
   DOMContentLoaded — событие, когда DOM уже полностью построен.
   Здесь мы:
   1) находим форму и элементы
   2) навешиваем обработчики на кнопки и поля
   3) делаем начальную настройку формы (картинка/подписи)
 */
document.addEventListener("DOMContentLoaded", () => {
  // 1) Находим форму по id (должна быть <form id="calcForm">)
  const form = document.getElementById("calcForm");
  if (!form) return; // если форма не найдена — выходим (иначе всё упадёт)

  // 2) Берём коллекцию элементов формы.
  //    Теперь обращаемся строго через el: el.v1, el.v2, el.formType, el.ops
  const el = form.elements;

  // 3) Элементы вне формы (картинка и блок результата)
  const pic = document.getElementById("pic");       // <img id="pic">
  const out = document.getElementById("output");    // <div id="output">

  // 4) Кнопки (в HTML у них только id, inline onclick нет)
  const btnShow = document.getElementById("btnShow");   // "Показать"
  const btnCalc = document.getElementById("btnCalc");   // "Вычислить"
  const btnClear = document.getElementById("btnClear"); // "Очистить"


 
  // 6) Навешиваем события на кнопки.
  //    Это ключевое требование: обработчики должны быть в JS, не в HTML (узнал от людей что такое требование)
  btnShow.addEventListener("click", () => showForm(el, pic, out)); // смена формы и картинки
  btnCalc.addEventListener("click", () => calculate(el, out));     // валидация + вычисления
  btnClear.addEventListener("click", () => clearData(el, out));    // очистка

  // 7) Снятие ошибок при вводе (НЕ запрещаем ввод, только подсвечиваем при вычислении)
  //    input → срабатывает на каждое изменение текста в поле.
  el.v1.addEventListener("input", () => clearFieldError("row1", "v1", "err1"));
  el.v2.addEventListener("input", () => clearFieldError("row2", "v2", "err2"));

  // 8) Снятие ошибки выбора операций при изменении списка.
  //    change → срабатывает когда изменился выбор в select multiple.
  el.ops.addEventListener("change", () => {
    clearFieldError("rowOps", null, "errOps");
    const findLabel = document.getElementById("findLabel");
    if (findLabel) findLabel.classList.remove("errorText");
  });

  // 9) Начальная настройка формы:
  //    подписи и картинка должны соответствовать select при загрузке.
  showForm(el, pic, out);
});


/* 
   showForm(el, pic, out)
   Назначение:
   - Обработчик кнопки "Показать"
   - Меняет подписи полей ввода и картинку, согласно выбранной форме.
   - Очищает результат и снимает ошибки, чтобы не оставалось "старого состояния".
 */
function showForm(el, pic, out) {
  // Очистить результат (старый вывод может быть не актуален для новой формы)
  clearOutput(out);

  // Снять подсветку ошибок (полезно при смене формы)
  clearFieldError("row1", "v1", "err1");
  clearFieldError("row2", "v2", "err2");
  clearFieldError("rowOps", null, "errOps");

  // Убрать красное выделение заголовка операций, если было
  const findLabel = document.getElementById("findLabel");
  if (findLabel) findLabel.classList.remove("errorText");

  // Читаем выбранную форму: "alg" или "trig"
  const type = el.formType.value;

  // Подписи полей (label)
  const label1 = document.getElementById("label1");
  const label2 = document.getElementById("label2");

  if (type === "alg") {
    // Алгебраическая форма: z = a + bi
    // Поля: Re(z)=a и Im(z)=b
    pic.src = "pict_alg.png"; // картинка для алгебраической формы
    if (label1) label1.textContent = "Re(z):";
    if (label2) label2.textContent = "Im(z):";
    el.v1.placeholder = "например: 3.5";
    el.v2.placeholder = "например: -2";
  } else {
    // Тригонометрическая форма: z = r(cosφ + i sinφ)
    // Поля: r и φ (в градусах)
    pic.src = "pict_trig.png"; // картинка для тригонометрической формы
    if (label1) label1.textContent = "r:";
    if (label2) label2.textContent = "φ (град):";
    el.v1.placeholder = "например: 5";
    el.v2.placeholder = "например: 30";
  }
}


/* 
   calculate(el, out)
   Назначение:
   - Обработчик кнопки "Вычислить"
   - Делает:
       1) Сброс прошлого результата и ошибок
       2) Валидацию ввода (не блокируя ввод, а подсвечивая ошибки)
       3) Проверку, что выбрана хотя бы 1 операция
       4) Вычисление (приведение к a,b,r,φ)
       5) Вывод результатов в out
 */
function calculate(el, out) {
  // 1) очистка вывода и старых ошибок
  clearOutput(out);
  clearFieldError("row1", "v1", "err1");
  clearFieldError("row2", "v2", "err2");
  clearFieldError("rowOps", null, "errOps");

  const findLabel = document.getElementById("findLabel");
  if (findLabel) findLabel.classList.remove("errorText");

  // 2) форма ввода
  const type = el.formType.value;

  // 3) массив ошибок (чтобы показать всё сразу)
  const errors = [];

  // 4) парсим значения из полей как числа
  //    parseNumber позволяет "3,5" и не запрещает ввод (просто ok=false)
  const p1 = parseNumber(el.v1.value);
  const p2 = parseNumber(el.v2.value);

  // ВАЛИДАЦИЯ ПОЛЯ 1
  if (!p1.ok) {
    const msg = (type === "alg")
      ? "Ошибка: Re(z) должно быть числом (можно 3.5 или 3,5)."
      : "Ошибка: r должно быть числом (можно 3.5 или 3,5).";
    setFieldError("row1", "v1", "err1", msg);
    errors.push(msg);
  }

  // ВАЛИДАЦИЯ ПОЛЯ 2 
  if (!p2.ok) {
    const msg = (type === "alg")
      ? "Ошибка: Im(z) должно быть числом."
      : "Ошибка: φ должно быть числом (в градусах).";
    setFieldError("row2", "v2", "err2", msg);
    errors.push(msg);
  }

  //  ДОП. ПРАВИЛО ДЛЯ TRIG: r > 0 
  // В тригонометрической форме r — модуль, он должен быть строго положительным.
  if (type === "trig" && p1.ok && p1.value <= 0) {
    const msg = "Ошибка: r должно быть строго больше 0 (тригонометрическая форма).";
    setFieldError("row1", "v1", "err1", msg);
    errors.push(msg);
  }

  // ВАЛИДАЦИЯ ОПЕРАЦИЙ 
  // Пользователь должен выбрать хотя бы одну операцию.
  const ops = getSelectedOps(el.ops);
  if (ops.length === 0) {
    const msg = "Ошибка: выберите хотя бы одну операцию в списке.";
    setFieldError("rowOps", null, "errOps", msg);
    if (findLabel) findLabel.classList.add("errorText");
    errors.push(msg);
  }

  // 5) если ошибки есть — выводим причины и прекращаем вычисление
  if (errors.length > 0) {
    appendLine(out, "<b>Исправьте ошибки ввода:</b>");
    const ul = document.createElement("ul");
    errors.forEach(e => {
      const li = document.createElement("li");
      li.textContent = e;
      ul.appendChild(li);
    });
    out.appendChild(ul);
    return;
  }

  // 6) Если ошибок нет — вычисляем (a,b,r,φ)
  let a, b, r, phiRad, phiDeg;

  if (type === "alg") {
    // Алгебраическая форма: a = Re, b = Im
    a = p1.value;
    b = p2.value;

    // Модуль: r = sqrt(a^2 + b^2)
    r = Math.hypot(a, b);

    // Аргумент: φ = atan2(b, a) (в радианах)
    phiRad = Math.atan2(b, a);

    // В градусы — чтобы красивее выводить тригонометрическую форму
    phiDeg = radToDeg(phiRad);
  } else {
    // Тригонометрическая форма: вводим r и φ(град)
    r = p1.value;
    phiDeg = p2.value;

    // Переводим φ в радианы для sin/cos
    phiRad = degToRad(phiDeg);

    // a = r cosφ, b = r sinφ
    a = r * Math.cos(phiRad);
    b = r * Math.sin(phiRad);
  }

  // 7) Вывод результатов по выбранным операциям
  appendLine(out, "<b>Результаты:</b>");

  for (const op of ops) {
    // Аргумент
    if (op === "arg") {
      // для alg выводим радианы, для trig — градусы (как вводили φ)
      appendLine(out, type === "alg"
        ? `arg(z) = ${fmt(phiRad)} рад`
        : `arg(z) = ${fmt(phiDeg)}°`);
    }

    // Мнимая часть
    if (op === "im") {
      appendLine(out, `Im(z) = ${fmt(b)}`);
    }

    // Модуль
    if (op === "mod") {
      appendLine(out, `|z| = ${fmt(r)}`);
    }

    // Представление в остальных формах
    if (op === "forms") {
      if (type === "alg") {
        // Вводили alg → покажем trig
        appendLine(out, `<u>Тригонометрическая форма:</u>`);
        appendLine(out, `z = ${fmt(r)} (cos ${fmt(phiDeg)}° + i sin ${fmt(phiDeg)}°)`);
      } else {
        // Вводили trig → покажем alg
        appendLine(out, `<u>Алгебраическая форма:</u>`);
        const sign = (b >= 0) ? "+" : "-";
        appendLine(out, `z = ${fmt(a)} ${sign} ${fmt(Math.abs(b))}i`);
      }
    }
  }
}


/* 
   clearData(el, out)
   Назначение:
   - Обработчик кнопки "Очистить"
   - Очищает:
       • поля ввода
       • выбранные операции
       • ошибки и причины
       • блок результата
*/
function clearData(el, out) {
  // очистка полей
  el.v1.value = "";
  el.v2.value = "";

  // снять выбор в select multiple
  for (const opt of el.ops.options) opt.selected = false;

  // снять ошибки
  clearFieldError("row1", "v1", "err1");
  clearFieldError("row2", "v2", "err2");
  clearFieldError("rowOps", null, "errOps");

  const findLabel = document.getElementById("findLabel");
  if (findLabel) findLabel.classList.remove("errorText");

  // очистить вывод
  clearOutput(out);
}




/* clearOutput(out)
   Назначение: полностью очистить div#output */
function clearOutput(out) {
  out.innerHTML = "";
}

/* appendLine(parent, text)
   Назначение: добавить строку результата как <p> через DOM */
function appendLine(parent, text) {
  const p = document.createElement("p");
  p.innerHTML = text;
  parent.appendChild(p);
}

/* parseNumber(raw)
   Назначение: преобразовать ввод в число без запрета ввода:
   - поддерживаем запятую как десятичный разделитель
   - возвращаем {ok, value} */
function parseNumber(raw) {
  const s = String(raw).trim().replace(",", ".");
  if (s === "") return { ok: false, value: NaN };
  const n = Number(s);
  if (!Number.isFinite(n)) return { ok: false, value: NaN };
  return { ok: true, value: n };
}

/* fmt(n)
   Назначение: форматирование числа для вывода:
   - округление до 3 знаков
   - убираем -0.000 */
function fmt(n) {
  let x = Math.round(n * 1000) / 1000;
  if (Math.abs(x) < 0.0005) x = 0;
  return x.toFixed(3);
}

/* degToRad / radToDeg
   Назначение: перевод угла, т.к. Math.sin/Math.cos работают в радианах */
function degToRad(deg) { return (deg * Math.PI) / 180; }
function radToDeg(rad) { return (rad * 180) / Math.PI; }

/* getSelectedOps(selectEl)
   Назначение: получить значения выбранных option из select multiple */
function getSelectedOps(selectEl) {
  const res = [];
  for (const opt of selectEl.options) if (opt.selected) res.push(opt.value);
  return res;
}


/*  ФУНКЦИИ ПОДСВЕТКИ ОШИБОК (стили + причина)

/* setFieldError(rowId, inputId, errId, msg)
   Назначение:
   - подсветить строку и поле красным (CSS классы)
   - вывести причину ошибки в span */
function setFieldError(rowId, inputId, errId, msg) {
  const row = document.getElementById(rowId);                 // строка поля/блок
  const inp = inputId ? document.getElementById(inputId) : null; // input (если есть)
  const err = document.getElementById(errId);                 // span для сообщения

  if (row) row.classList.add("error-field");       // красная рамка + фон
  if (inp) inp.classList.add("error-input");       // красная рамка input
  if (err) err.textContent = msg;                  // причина ошибки
}

/* clearFieldError(rowId, inputId, errId)
   Назначение:
   - снять подсветку ошибок
   - удалить текст причины */
function clearFieldError(rowId, inputId, errId) {
  const row = document.getElementById(rowId);
  const inp = inputId ? document.getElementById(inputId) : null;
  const err = document.getElementById(errId);

  if (row) row.classList.remove("error-field");
  if (inp) inp.classList.remove("error-input");
  if (err) err.textContent = "";
}
