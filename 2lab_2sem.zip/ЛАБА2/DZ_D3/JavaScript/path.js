function createCardioidPoints() {
    const svg = d3.select("#scene");
    const width = +svg.attr("width");
    const height = +svg.attr("height");

    let data = [];

    const centerX = width / 2;
    const cuspY = height - 200;
    const scale = Math.min(width, height) / 3;

    // Старт из нижней точки, движение против часовой стрелки
    for (let t = Math.PI; t <= Math.PI + 2 * Math.PI + 0.02; t += 0.02) {
        const r = 1 + Math.cos(t);

        const x = centerX - scale * r * Math.sin(t);
        const y = cuspY - scale * r * Math.cos(t);

        data.push({ x, y });
    }

    return data;
}

function drawCardioidPath(showPath = true) {
    const dataPoints = createCardioidPoints();

    const line = d3.line()
        .x(d => d.x)
        .y(d => d.y);

    const svg = d3.select("#scene");

    const path = svg.append("path")
        .attr("class", "trajectory")
        .attr("d", line(dataPoints))
        .attr("fill", "none")
        .attr("stroke", showPath ? "blue" : "none")
        .attr("stroke-width", 2);

    return path;
}

function translateAlong(path, sxStart, syStart, sxEnd, syEnd, angleStart, angleEnd) {
    const length = path.getTotalLength();

    const sxInterpolator = d3.interpolateNumber(sxStart, sxEnd);
    const syInterpolator = d3.interpolateNumber(syStart, syEnd);
    const angleInterpolator = d3.interpolateNumber(angleStart, angleEnd);

    return function () {
        return function (t) {
            const point = path.getPointAtLength(t * length);

            const currentSx = sxInterpolator(t);
            const currentSy = syInterpolator(t);
            const currentAngle = angleInterpolator(t);

            return `translate(${point.x}, ${point.y}) scale(${currentSx}, ${currentSy}) rotate(${currentAngle})`;
        };
    };
}