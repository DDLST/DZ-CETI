function drawBoat(svg) {
    const boat = svg.append("g")
        .attr("class", "boat")
        .style("stroke-linejoin", "round")
        .style("stroke-linecap", "round");

    // Корпус лодочки
    boat.append("path")
        .attr("d", "M -40 20 L 40 20 L 25 40 L -25 40 Z")
        .attr("fill", "#8b5a2b")
        .attr("stroke", "#3b2a1a")
        .attr("stroke-width", 2);

    // ПОДОБИЕ Мачты
    boat.append("line")
        .attr("x1", 0)
        .attr("y1", -40)
        .attr("x2", 0)
        .attr("y2", 20)
        .attr("stroke", "#3b2a1a")
        .attr("stroke-width", 3);

    // ПАРУС1
    boat.append("polygon")
        .attr("points", "0,-35 -30,5 0,5")
        .attr("fill", "#f2f2f2")
        .attr("stroke", "#555")
        .attr("stroke-width", 1.5);

    // ПАРУС2
    boat.append("polygon")
        .attr("points", "0,-30 28,-5 0,-5")
        .attr("fill", "#d9ecff")
        .attr("stroke", "#555")
        .attr("stroke-width", 1.5);

    // ВОЛНА1
    boat.append("path")
        .attr("d", "M -35 48 Q -20 38 -5 48 T 25 48")
        .attr("fill", "none")
        .attr("stroke", "#2b7de9")
        .attr("stroke-width", 2);

    // 6. ВОЛНА2
    boat.append("path")
        .attr("d", "M -20 58 Q -5 48 10 58 T 40 58")
        .attr("fill", "none")
        .attr("stroke", "#2b7de9")
        .attr("stroke-width", 2);

    return boat;
}