document.addEventListener("DOMContentLoaded", function () {
    const width = 900;
    const height = 700;

    const svg = d3.select("#scene")
        .attr("width", width)
        .attr("height", height);

    const form = document.getElementById("setting");

    const drawBtn = document.getElementById("drawBtn");
    const animateBtn = document.getElementById("animateBtn");
    const clearBtn = document.getElementById("clearBtn");

    const useAnimation = document.getElementById("useAnimation");
    const moveAlongPath = document.getElementById("moveAlongPath");

    const coordsBlock = document.getElementById("coordsBlock");
    const pathBlock = document.getElementById("pathBlock");
    const scaleBlock = document.getElementById("scaleBlock");
    const rotateBlock = document.getElementById("rotateBlock");

    const easingWrapper = document.getElementById("easingWrapper");
    const durationWrapper = document.getElementById("durationWrapper");
    const pathToggleWrapper = document.getElementById("pathToggleWrapper");

    const coordFinishFields = document.querySelectorAll(".coord-finish");
    const transformFinishFields = document.querySelectorAll(".transform-finish");

    const getEaseFunction = (type) => {
        switch (type) {
            case "elastic":
                return d3.easeElastic;
            case "bounce":
                return d3.easeBounce;
            default:
                return d3.easeLinear;
        }
    };

    const updateFormMode = () => {
        const isAnimated = useAnimation.checked;
        const isPathMode = moveAlongPath.checked;

        if (!isAnimated) {
            drawBtn.style.display = "inline-block";
            animateBtn.style.display = "none";

            easingWrapper.style.display = "none";
            durationWrapper.style.display = "none";
            pathToggleWrapper.style.display = "none";

            coordsBlock.style.display = "block";
            pathBlock.style.display = "none";
            scaleBlock.style.display = "block";
            rotateBlock.style.display = "block";

            coordFinishFields.forEach(field => field.style.display = "none");
            transformFinishFields.forEach(field => field.style.display = "none");
        } else {
            drawBtn.style.display = "none";
            animateBtn.style.display = "inline-block";

            easingWrapper.style.display = "inline-block";
            durationWrapper.style.display = "inline-block";
            pathToggleWrapper.style.display = "inline-block";

            if (!isPathMode) {
                coordsBlock.style.display = "block";
                pathBlock.style.display = "none";
                scaleBlock.style.display = "block";
                rotateBlock.style.display = "block";

                coordFinishFields.forEach(field => field.style.display = "inline-block");
                transformFinishFields.forEach(field => field.style.display = "inline-block");
            } else {
                coordsBlock.style.display = "none";
                pathBlock.style.display = "block";
                scaleBlock.style.display = "block";
                rotateBlock.style.display = "block";

                coordFinishFields.forEach(field => field.style.display = "none");
                transformFinishFields.forEach(field => field.style.display = "inline-block");
            }
        }
    };

    const draw = (dataForm) => {
        const cx = +dataForm.elements.cx.value;
        const cy = +dataForm.elements.cy.value;
        const sx = +dataForm.elements.sx.value;
        const sy = +dataForm.elements.sy.value;
        const angle = +dataForm.elements.angle.value;

        const pict = drawBoat(svg);

        pict.attr(
            "transform",
            `translate(${cx}, ${cy}) scale(${sx}, ${sy}) rotate(${angle})`
        );
    };

    const runAnimation = (dataForm) => {
        const duration = Math.max(100, +dataForm.elements.duration.value);
        const easeFunction = getEaseFunction(dataForm.elements.easingType.value);

        const sx = +dataForm.elements.sx.value;
        const sy = +dataForm.elements.sy.value;
        const sxFinish = +dataForm.elements.sx_finish.value;
        const syFinish = +dataForm.elements.sy_finish.value;
        const angle = +dataForm.elements.angle.value;
        const angleFinish = +dataForm.elements.angle_finish.value;

        const pict = drawBoat(svg);

        if (!dataForm.elements.moveAlongPath.checked) {
            const cx = +dataForm.elements.cx.value;
            const cy = +dataForm.elements.cy.value;
            const cxFinish = +dataForm.elements.cx_finish.value;
            const cyFinish = +dataForm.elements.cy_finish.value;

            pict.attr(
                "transform",
                `translate(${cx}, ${cy}) scale(${sx}, ${sy}) rotate(${angle})`
            )
            .transition()
            .duration(duration)
            .ease(easeFunction)
            .attr(
                "transform",
                `translate(${cxFinish}, ${cyFinish}) scale(${sxFinish}, ${syFinish}) rotate(${angleFinish})`
            );
        } else {
            svg.selectAll(".trajectory").remove();

            const path = drawCardioidPath(true);
            const pathNode = path.node();
            const startPoint = pathNode.getPointAtLength(0);

            pict.attr(
                "transform",
                `translate(${startPoint.x}, ${startPoint.y}) scale(${sx}, ${sy}) rotate(${angle})`
            )
            .transition()
            .duration(duration)
            .ease(easeFunction)
            .attrTween(
                "transform",
                translateAlong(pathNode, sx, sy, sxFinish, syFinish, angle, angleFinish)
            );
        }
    };

    drawBtn.addEventListener("click", function () {
        draw(form);
    });

    animateBtn.addEventListener("click", function () {
        runAnimation(form);
    });

    clearBtn.addEventListener("click", function () {
        svg.selectAll("*").remove();
    });

    useAnimation.addEventListener("change", updateFormMode);
    moveAlongPath.addEventListener("change", updateFormMode);

    updateFormMode();
});