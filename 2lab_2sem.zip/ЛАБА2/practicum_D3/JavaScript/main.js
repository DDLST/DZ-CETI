document.addEventListener("DOMContentLoaded", function () {
    const width = 600;
    const height = 600;

    const svg = d3.select("svg")
        .attr("width", width)
        .attr("height", height);

    const form = document.getElementById("setting");

    const drawBtn = document.getElementById("drawBtn");
    const clearBtn = document.getElementById("clearBtn");
    const animateBtn = document.getElementById("animateBtn");

    const useAnimation = document.getElementById("useAnimation");
    const moveAlongPath = document.getElementById("moveAlongPath");

    const coordsBlock = document.getElementById("coordsBlock");
    const pathBlock = document.getElementById("pathBlock");
    const scaleBlock = document.getElementById("scaleBlock");
    const rotateBlock = document.getElementById("rotateBlock");

    const animationTypeWrapper = document.getElementById("animationTypeWrapper");
    const pathToggleWrapper = document.getElementById("pathToggleWrapper");

    const finishFields = document.querySelectorAll(".finish-field");

    const getEaseFunction = (type) => {
        switch (type) {
            case "elastic":
                return d3.easeElastic;
            case "bounce":
                return d3.easeBounce;
            default:
                return d3.easeLinear;
        }
    };

    const updateFormMode = () => {
        const isAnimated = useAnimation.checked;
        const isPathMode = moveAlongPath.checked;

        // поля конечных значений
        finishFields.forEach(field => {
            field.style.display = (isAnimated && !isPathMode) ? "inline-block" : "none";
        });

        // кнопки и общие элементы
        drawBtn.style.display = isAnimated ? "none" : "inline-block";
        animateBtn.style.display = isAnimated ? "inline-block" : "none";
        animationTypeWrapper.style.display = isAnimated ? "inline-block" : "none";
        pathToggleWrapper.style.display = isAnimated ? "block" : "none";

        if (!isAnimated) {
            // обычное рисование
            coordsBlock.style.display = "block";
            pathBlock.style.display = "none";
            scaleBlock.style.display = "block";
            rotateBlock.style.display = "block";
        } else {
            if (!isPathMode) {
                // обычная анимация
                coordsBlock.style.display = "block";
                pathBlock.style.display = "none";
                scaleBlock.style.display = "block";
                rotateBlock.style.display = "block";
            } else {
                // анимация по пути
                coordsBlock.style.display = "none";
                pathBlock.style.display = "block";
                scaleBlock.style.display = "none";
                rotateBlock.style.display = "none";
            }
        }
    };

    const draw = (dataForm) => {
        const cx = +dataForm.elements.cx.value;
        const cy = +dataForm.elements.cy.value;
        const sx = +dataForm.elements.sx.value;
        const sy = +dataForm.elements.sy.value;
        const angle = +dataForm.elements.angle.value;

        const pict = drawSmile(svg);

        pict.attr(
            "transform",
            `translate(${cx}, ${cy}) scale(${sx}, ${sy}) rotate(${angle})`
        );
    };

    const runAnimation = (dataForm) => {
        const easeFunction = getEaseFunction(dataForm.elements.animationType.value);

        const pict = drawSmile(svg);

        if (!dataForm.elements.moveAlongPath.checked) {
            // обычная анимация: перемещение + масштаб + поворот
            const cx = +dataForm.elements.cx.value;
            const cy = +dataForm.elements.cy.value;
            const sx = +dataForm.elements.sx.value;
            const sy = +dataForm.elements.sy.value;
            const angle = +dataForm.elements.angle.value;

            const cxFinish = +dataForm.elements.cx_finish.value;
            const cyFinish = +dataForm.elements.cy_finish.value;
            const sxFinish = +dataForm.elements.sx_finish.value;
            const syFinish = +dataForm.elements.sy_finish.value;
            const angleFinish = +dataForm.elements.angle_finish.value;

            pict.attr(
                "transform",
                `translate(${cx}, ${cy}) scale(${sx}, ${sy}) rotate(${angle})`
            )
            .transition()
            .duration(6000)
            .ease(easeFunction)
            .attr(
                "transform",
                `translate(${cxFinish}, ${cyFinish}) scale(${sxFinish}, ${syFinish}) rotate(${angleFinish})`
            );

        } else {
            // анимация вдоль пути
            const pathType = +dataForm.elements.pathType.value;
            const path = drawPath(pathType);

            const pathNode = path.node();
            const startPoint = pathNode.getPointAtLength(0);

            pict.attr("transform", `translate(${startPoint.x}, ${startPoint.y})`)
                .transition()
                .duration(6000)
                .ease(easeFunction)
                .attrTween("transform", translateAlong(pathNode))
                .on("end", function () {
                    path.remove();
                });
        }
    };

    drawBtn.addEventListener("click", function () {
        draw(form);
    });

    animateBtn.addEventListener("click", function () {
        runAnimation(form);
    });

    clearBtn.addEventListener("click", function () {
        svg.selectAll("*").remove();
    });

    useAnimation.addEventListener("change", updateFormMode);
    moveAlongPath.addEventListener("change", updateFormMode);

    updateFormMode();
});